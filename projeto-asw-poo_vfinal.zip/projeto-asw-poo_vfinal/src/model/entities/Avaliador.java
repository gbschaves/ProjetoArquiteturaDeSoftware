package model.entities;

public class Avaliador {
    private String nome;
    private String email;
    private String telefone;
    private String cpf;
    private String rne;
    private String lattes;
    private String instituicaoQueTrabalha;
    private Integer researchId;
}
