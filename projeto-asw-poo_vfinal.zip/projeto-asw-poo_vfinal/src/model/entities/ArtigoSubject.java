package model.entities;
import java.util.ArrayList;
import java.util.List;
public abstract class ArtigoSubject {
    private List<ArtigoObserver> observers = new ArrayList<>();

    public void addObserver(ArtigoObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(ArtigoObserver observer) {
        observers.remove(observer);
    }

    protected void notifyObservers(Artigo artigo) {
        for (ArtigoObserver observer : observers) {
            observer.update(artigo);
        }
    }
}
