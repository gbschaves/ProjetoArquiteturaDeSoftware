package model.entities;

public interface ArtigoObserver {
    void update(Artigo artigo);
}
