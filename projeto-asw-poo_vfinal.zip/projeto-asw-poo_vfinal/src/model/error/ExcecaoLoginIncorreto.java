package model.error;

public class ExcecaoLoginIncorreto extends Exception {
    public ExcecaoLoginIncorreto(String mensagem){
        super(mensagem);
    }
}
